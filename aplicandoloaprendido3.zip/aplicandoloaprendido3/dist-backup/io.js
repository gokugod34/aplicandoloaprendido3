"use strict";

import { createInterface } from "readline";

class InputHandler {
    constructor() {
        this.rl = createInterface({
            input: process.stdin,
            output: process.stdout,
        });
    }

    input(question) {
        return new Promise((resolve) => {
            this.rl.question(question, (answer) => resolve(answer));
        });
    }
}


const inputHandler = new InputHandler();

export const rl = inputHandler.rl;
export const input = inputHandler.input;