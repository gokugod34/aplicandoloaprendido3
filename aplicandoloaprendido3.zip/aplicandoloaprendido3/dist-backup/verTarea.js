"use strict";

import { input } from "./io";
import { getTareas } from "./agregarTarea";

class TaskViewer {
    async verTarea() {
        let tareas = getTareas();
        if (tareas.length === 0) {
            console.log("No hay tareas registradas.");
            return;
        }
        
        let opcion;
        do {
            console.log("¿Qué tareas deseas ver?\n  [1] - Todas\n  [2] - Pendientes\n  [3] - En curso\n  [4] - Terminadas\n  [5] - Canceladas\n  [0] - Volver\n");
            opcion = Number(await input("⋙ "));
            
            switch (opcion) {
                case 1:
                    await this.verTodas();
                    break;
                case 2:
                    await this.pendientes();
                    break;
                case 3:
                    await this.enCurso();
                    break;
                case 4:
                    await this.terminadas();
                    break;
                case 5:
                    await this.cancelada();
                    break;
                case 0:
                    console.log("Volviendo al menú.\n");
                    break;
                default:
                    console.log("Opción incorrecta.");
                    break;
            }
        } while (opcion !== 0);
    }

    async verTodas() {
        let tareas = getTareas();
        for (let i = 0; i < tareas.length; i++) {
            console.log(`Tarea [${i + 1}] - Título: ${tareas[i].titulo}`);
            console.log(`Descripción: ${tareas[i].descripcion}`);
            console.log(`Estado: ${tareas[i].estado}`);
            console.log(`Dificultad: ${tareas[i].dificultad}`);
            console.log("---- ---- ---- ---- ---- ----\n");
        }
    }

    async pendientes() {
        let tareas = getTareas();
        let hayPendientes = false;
        for (let i = 0; i < tareas.length; i++) {
            if (tareas[i].estado === "Pendiente") {
                hayPendientes = true;
                console.log(`Tarea [${i + 1}] - Título: ${tareas[i].titulo}`);
                console.log(`Descripción: ${tareas[i].descripcion}`);
                console.log(`Estado: ${tareas[i].estado}`);
                console.log("---- ---- ---- ---- ---- ----\n");
            }
        }
        if (!hayPendientes) {
            console.log("No hay tareas pendientes.\n");
        }
    }

    async enCurso() {
        let tareas = getTareas();
        let hayEnCurso = false;  
        console.log("---- TAREAS EN CURSO ----\n");
        for (let i = 0; i < tareas.length; i++) {
            if (tareas[i].estado === "En curso") {
                hayEnCurso = true;
                console.log(`Tarea [${i + 1}] - Título: ${tareas[i].titulo}`);
                console.log(`Descripción: ${tareas[i].descripcion}`);
                console.log(`Estado: ${tareas[i].estado}`);
                console.log("---- ---- ---- ---- ---- ----\n");
            }
        }
        if (!hayEnCurso) {
            console.log("No hay tareas en curso.\n");
        }
    }

    async terminadas() {
        let tareas = getTareas();
        let hayTerminadas = false;  
        console.log("---- TAREAS TERMINADAS ----\n");
        for (let i = 0; i < tareas.length; i++) {
            if (tareas[i].estado === "Terminada") {
                hayTerminadas = true;
                console.log(`Tarea [${i + 1}] - Título: ${tareas[i].titulo}`);
                console.log(`Descripción: ${tareas[i].descripcion}`);
                console.log(`Estado: ${tareas[i].estado}`);
                console.log("---- ---- ---- ---- ---- ----\n");
            }
        }
        if (!hayTerminadas) {
            console.log("No hay tareas terminadas.\n");
        }
    }

    async cancelada() {
        let tareas = getTareas();
        let hayCanceladas = false;  
        console.log("---- TAREAS CANCELADAS ----\n");  
        for (let i = 0; i < tareas.length; i++) {
            if (tareas[i].estado === "Cancelada") {
                hayCanceladas = true;
                console.log(`Tarea [${i + 1}] - Título: ${tareas[i].titulo}`);
                console.log(`Descripción: ${tareas[i].descripcion}`);
                console.log(`Estado: ${tareas[i].estado}`);
                console.log("---- ---- ---- ---- ---- ----\n");
            }
        }
        if (!hayCanceladas) {
            console.log("No hay tareas canceladas.\n");
        }
    }
}


const taskViewer = new TaskViewer();

export const verTarea = taskViewer.verTarea;