"use strict";

import { menu } from "./menu";  
console.log("Iniciando la aplicación de gestión de tareas...\n");
class Application {
    
    

    run() {
        
        menu();
    }
}


const app = new Application();
app.run();